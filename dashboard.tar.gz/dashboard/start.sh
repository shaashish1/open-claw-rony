#!/bin/bash
# ITGYANI Dashboard — Start Script
# RULE: DRAFT ONLY - Never send emails

set -a
source /root/.openclaw/workspace/config/.env
set +a

# Gmail app passwords (spaces in passwords need special handling)
export GMAIL_PERSONAL_PASS="eysg infz zxja srtl"
export GMAIL_ITGYANI_PASS="ozdi cwfy hncm nkzl"
export TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-placeholder}"

mkdir -p /root/.openclaw/workspace/dashboard/data

cd /root/.openclaw/workspace/dashboard/backend
exec /root/.openclaw/workspace/dashboard/venv/bin/uvicorn main:app \
  --host 0.0.0.0 \
  --port 8000 \
  --log-level info
